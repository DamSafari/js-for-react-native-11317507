My name is Afari Damien Sena and my student ID is 11317507.
In this file I am going to briefly explain each task of the assignment.

Task 1 involves creating a JavaScript function that can take an array of numbers as an argument and return values based on certain conditions.

In task 2, I was required to use the function from task 1 and another function in this task which takes the processed array from the first function and use that to convert the string to capital or small case depending on the number.

In task 3, I created another file that uses the function from the task two in a function that creates user profiles and then returns an array with the original name and the modified name.

Finally in task 4, I am to create a README file that explains all the tasks above.
